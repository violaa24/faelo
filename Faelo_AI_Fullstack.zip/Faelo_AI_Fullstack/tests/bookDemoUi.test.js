const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');

const projectRoot = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(projectRoot, 'public/index.html'), 'utf8');
const script = fs.readFileSync(path.join(projectRoot, 'public/js/script.js'), 'utf8');

function createPage(fetchImplementation) {
    const dom = new JSDOM(html, {
        runScripts: 'outside-only',
        pretendToBeVisual: true,
        url: 'http://127.0.0.1:3000/'
    });

    dom.window.fetch = fetchImplementation;
    dom.window.HTMLElement.prototype.scrollIntoView = () => {};
    dom.window.eval(script);
    dom.window.document.dispatchEvent(new dom.window.Event('DOMContentLoaded'));

    return dom;
}

function fillRequiredFields(document) {
    const values = {
        firstName: 'Aldo',
        lastName: 'Kusuma',
        email: 'aldo@example.com',
        phone: '+62 812 3456 7890',
        jobTitle: 'Plant Manager',
        companyName: 'Example Manufacturing',
        countryRegion: 'Indonesia',
        manufacturingIndustry: 'Packaging',
        currentDataSources: 'ERP and Excel',
        primaryFactoryChallenge: 'High rejection rate',
        factoryQuestion: 'Why is the rejection rate high?'
    };

    for (const [name, value] of Object.entries(values)) {
        document.querySelector(`[name="${name}"]`).value = value;
    }

    document.querySelector('[name="consent"]').checked = true;
}

test('every Book a Demo button opens the form and both close controls work', () => {
    const dom = createPage(async () => ({ ok: true, json: async () => ({}) }));
    const { document } = dom.window;
    const modal = document.getElementById('demoModal');
    const openButtons = [...document.querySelectorAll('[data-open-demo]')];
    const closeButtons = [...document.querySelectorAll('[data-close-demo]')];

    assert.equal(openButtons.length, 3);
    assert.equal(closeButtons.length, 2);

    for (const button of openButtons) {
        button.click();
        assert.equal(modal.style.display, 'block');
        closeButtons[0].click();
        assert.equal(modal.style.display, 'none');
    }

    openButtons[0].click();
    closeButtons[1].click();
    assert.equal(modal.style.display, 'none');

    dom.window.close();
});

test('submitting the form sends JSON to the API and shows the success state', async () => {
    let capturedRequest;
    const dom = createPage(async (url, options) => {
        capturedRequest = { url, options };
        return {
            ok: true,
            json: async () => ({ requestId: '8d35489f-ec1c-47f0-a9c4-2e43afbc004b' })
        };
    });
    const { document } = dom.window;

    document.querySelector('[data-open-demo]').click();
    fillRequiredFields(document);
    document.getElementById('demoForm').dispatchEvent(new dom.window.Event('submit', {
        bubbles: true,
        cancelable: true
    }));

    await new Promise((resolve) => dom.window.setTimeout(resolve, 20));

    assert.equal(capturedRequest.url, '/api/demo-requests');
    assert.equal(capturedRequest.options.method, 'POST');
    assert.equal(JSON.parse(capturedRequest.options.body).companyName, 'Example Manufacturing');
    assert.equal(document.getElementById('demoForm').style.display, 'none');
    assert.equal(document.getElementById('successState').style.display, 'flex');

    dom.window.close();
});

test('a failed API request keeps the form open and displays a recoverable error', async () => {
    const dom = createPage(async () => ({
        ok: false,
        json: async () => ({ message: 'Database is temporarily unavailable.' })
    }));
    const { document } = dom.window;

    document.querySelector('[data-open-demo]').click();
    fillRequiredFields(document);
    document.getElementById('demoForm').dispatchEvent(new dom.window.Event('submit', {
        bubbles: true,
        cancelable: true
    }));

    await new Promise((resolve) => dom.window.setTimeout(resolve, 20));

    assert.equal(document.getElementById('demoForm').style.display, 'block');
    assert.equal(document.getElementById('successState').style.display, 'none');
    assert.equal(document.getElementById('formMessage').hidden, false);
    assert.match(document.getElementById('formMessage').textContent, /temporarily unavailable/);

    dom.window.close();
});
