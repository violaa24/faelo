const test = require('node:test');
const assert = require('node:assert/strict');
const { validateDemoRequest } = require('../src/validation/demoRequest');

function validPayload() {
    return {
        firstName: 'Aldo',
        lastName: 'Kusuma',
        email: 'Aldo@Example.com',
        phone: '+62 812-3456-7890',
        jobTitle: 'Plant Manager',
        companyName: 'Example Manufacturing',
        countryRegion: 'Indonesia',
        manufacturingIndustry: 'Flexible Packaging',
        currentDataSources: 'ERP and Excel',
        primaryFactoryChallenge: 'High rejection rate',
        factoryQuestion: 'Why is the rejection rate high on Line 3?',
        consent: true,
        website: ''
    };
}

test('accepts and normalizes a complete demo request', () => {
    const result = validateDemoRequest(validPayload());
    assert.equal(result.isValid, true);
    assert.equal(result.isBot, false);
    assert.equal(result.data.email, 'aldo@example.com');
});

test('rejects missing required information', () => {
    const payload = validPayload();
    payload.companyName = '';
    payload.consent = false;

    const result = validateDemoRequest(payload);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.companyName);
    assert.ok(result.errors.consent);
});

test('rejects malformed email and phone values', () => {
    const payload = validPayload();
    payload.email = 'not-an-email';
    payload.phone = 'phone???';

    const result = validateDemoRequest(payload);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.email);
    assert.ok(result.errors.phone);
});

test('detects a filled honeypot field as a bot submission', () => {
    const payload = validPayload();
    payload.website = 'https://spam.example';

    const result = validateDemoRequest(payload);
    assert.equal(result.isBot, true);
});
