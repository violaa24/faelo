const { test, after } = require('node:test');
const assert = require('node:assert/strict');

process.env.DB_PASSWORD = 'test-password';

const { pool } = require('../src/config/database');
const { createDemoRequest } = require('../src/repositories/demoRequestRepository');

after(async () => {
    await pool.end();
});

test('stores a demo request with a parameterized query', async (context) => {
    const originalQuery = pool.query.bind(pool);
    let capturedSql;
    let capturedValues;

    pool.query = async (sql, values) => {
        capturedSql = sql;
        capturedValues = values;
        return {
            rows: [{
                request_id: values[0],
                created_at: new Date('2026-09-10T00:00:00.000Z')
            }]
        };
    };

    context.after(() => {
        pool.query = originalQuery;
    });

    const saved = await createDemoRequest({
        firstName: 'Aldo',
        lastName: 'Kusuma',
        email: 'aldo@example.com',
        phone: '+62 812 3456 7890',
        jobTitle: 'Plant Manager',
        companyName: 'Example Manufacturing',
        countryRegion: 'Indonesia',
        manufacturingIndustry: 'Packaging',
        currentDataSources: 'ERP and Excel',
        primaryFactoryChallenge: 'Rejection rate',
        factoryQuestion: 'Why is rejection high?',
        consent: true
    });

    assert.match(capturedSql, /VALUES \(\$1, \$2, \$3, \$4/);
    assert.equal(capturedValues.length, 13);
    assert.equal(capturedValues[1], 'Aldo');
    assert.equal(capturedValues[3], 'aldo@example.com');
    assert.equal(capturedValues[12], true);
    assert.equal(saved.request_id, capturedValues[0]);
});
