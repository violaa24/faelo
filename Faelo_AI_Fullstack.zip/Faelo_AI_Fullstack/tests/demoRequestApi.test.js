const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

process.env.DB_PASSWORD = 'test-password';

const { pool } = require('../src/config/database');
const app = require('../src/app');

let server;
let baseUrl;
let insertCount = 0;
const originalQuery = pool.query.bind(pool);

function completePayload() {
    return {
        firstName: 'Aldo',
        lastName: 'Kusuma',
        email: 'aldo@example.com',
        phone: '+62 812 3456 7890',
        jobTitle: 'Plant Manager',
        companyName: 'Example Manufacturing',
        countryRegion: 'Indonesia',
        manufacturingIndustry: 'Packaging',
        currentDataSources: 'ERP and Excel',
        primaryFactoryChallenge: 'High rejection rate',
        factoryQuestion: 'Why is the rejection rate high?',
        consent: true,
        website: ''
    };
}

before(async () => {
    pool.query = async (sql, values) => {
        if (/SELECT NOW/.test(sql)) {
            return { rows: [{ database_time: new Date('2026-09-10T00:00:00.000Z') }] };
        }

        if (/INSERT INTO demo_requests/.test(sql)) {
            insertCount += 1;
            return {
                rows: [{
                    request_id: values[0],
                    created_at: new Date('2026-09-10T00:00:00.000Z')
                }]
            };
        }

        return originalQuery(sql, values);
    };

    server = await new Promise((resolve) => {
        const instance = app.listen(0, '127.0.0.1', () => resolve(instance));
    });
    const address = server.address();
    baseUrl = `http://127.0.0.1:${address.port}`;
});

after(async () => {
    pool.query = originalQuery;
    await new Promise((resolve) => server.close(resolve));
    await pool.end();
});

test('serves the approved Faelo AI website', async () => {
    const response = await fetch(`${baseUrl}/`);
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /Ask your factory/);
    assert.match(html, /id="demoForm"/);
    assert.match(html, /data-open-demo/);
    assert.doesNotMatch(html, /on(?:click|submit)=/i);
    assert.match(response.headers.get('content-security-policy'), /script-src-attr 'none'/);
});

test('reports a working application and database connection', async () => {
    const response = await fetch(`${baseUrl}/api/health`);
    const body = await response.json();

    assert.equal(response.status, 200);
    assert.equal(body.status, 'ok');
    assert.equal(body.database, 'connected');
});

test('validates and stores a complete Book a Demo submission', async () => {
    const response = await fetch(`${baseUrl}/api/demo-requests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(completePayload())
    });
    const body = await response.json();

    assert.equal(response.status, 201);
    assert.equal(insertCount, 1);
    assert.match(body.requestId, /^[0-9a-f-]{36}$/);
});

test('rejects an incomplete Book a Demo submission without storing it', async () => {
    const payload = completePayload();
    payload.email = '';

    const response = await fetch(`${baseUrl}/api/demo-requests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    const body = await response.json();

    assert.equal(response.status, 422);
    assert.ok(body.errors.email);
    assert.equal(insertCount, 1);
});
