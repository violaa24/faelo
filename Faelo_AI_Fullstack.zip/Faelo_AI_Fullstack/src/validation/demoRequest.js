const FIELD_RULES = Object.freeze({
    firstName: { label: 'First name', max: 100, required: true },
    lastName: { label: 'Last name', max: 100, required: true },
    email: { label: 'Email', max: 254, required: true },
    phone: { label: 'Phone', max: 50, required: false },
    jobTitle: { label: 'Job title', max: 150, required: true },
    companyName: { label: 'Company name', max: 200, required: true },
    countryRegion: { label: 'Country / Region', max: 120, required: true },
    manufacturingIndustry: { label: 'Manufacturing Industry', max: 160, required: true },
    currentDataSources: { label: 'Current data sources', max: 500, required: true },
    primaryFactoryChallenge: { label: 'Primary factory challenge', max: 1000, required: true },
    factoryQuestion: { label: 'Factory question', max: 3000, required: true }
});

function cleanText(value) {
    return typeof value === 'string' ? value.trim() : '';
}

function validateDemoRequest(body) {
    const input = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
    const data = {};
    const errors = {};

    for (const [field, rule] of Object.entries(FIELD_RULES)) {
        const value = cleanText(input[field]);
        data[field] = value;

        if (rule.required && !value) {
            errors[field] = `${rule.label} is required.`;
        } else if (value.length > rule.max) {
            errors[field] = `${rule.label} cannot exceed ${rule.max} characters.`;
        }
    }

    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
        errors.email = 'Please enter a valid email address.';
    }

    if (data.phone && !/^[0-9+().\-\s]{6,50}$/.test(data.phone)) {
        errors.phone = 'Please enter a valid phone number.';
    }

    if (input.consent !== true) {
        errors.consent = 'Consent is required before submitting the request.';
    }

    data.email = data.email.toLowerCase();
    data.consent = input.consent === true;

    return {
        data,
        errors,
        isValid: Object.keys(errors).length === 0,
        isBot: cleanText(input.website).length > 0
    };
}

module.exports = { FIELD_RULES, validateDemoRequest };
