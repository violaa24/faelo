const { randomUUID } = require('node:crypto');
const { pool } = require('../config/database');

const INSERT_DEMO_REQUEST = `
    INSERT INTO demo_requests (
        request_id,
        first_name,
        last_name,
        email,
        phone,
        job_title,
        company_name,
        country_region,
        manufacturing_industry,
        current_data_sources,
        primary_factory_challenge,
        factory_question,
        consent
    )
    VALUES ($1, $2, $3, $4, NULLIF($5, ''), $6, $7, $8, $9, $10, $11, $12, $13)
    RETURNING request_id, created_at
`;

async function createDemoRequest(data) {
    const requestId = randomUUID();
    const values = [
        requestId,
        data.firstName,
        data.lastName,
        data.email,
        data.phone,
        data.jobTitle,
        data.companyName,
        data.countryRegion,
        data.manufacturingIndustry,
        data.currentDataSources,
        data.primaryFactoryChallenge,
        data.factoryQuestion,
        data.consent
    ];

    const result = await pool.query(INSERT_DEMO_REQUEST, values);
    return result.rows[0];
}

module.exports = { createDemoRequest };
