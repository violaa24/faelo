const path = require('node:path');
const dotenv = require('dotenv');

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

function readInteger(name, fallback, minimum, maximum) {
    const rawValue = process.env[name];
    const value = rawValue === undefined || rawValue === '' ? fallback : Number(rawValue);

    if (!Number.isInteger(value) || value < minimum || value > maximum) {
        throw new Error(`${name} must be a whole number between ${minimum} and ${maximum}.`);
    }

    return value;
}

function readBoolean(name, fallback = false) {
    const rawValue = process.env[name];
    if (rawValue === undefined || rawValue === '') return fallback;
    if (rawValue === 'true') return true;
    if (rawValue === 'false') return false;
    throw new Error(`${name} must be either true or false.`);
}

const config = Object.freeze({
    nodeEnv: process.env.NODE_ENV || 'development',
    host: process.env.HOST || '127.0.0.1',
    port: readInteger('PORT', 3000, 1, 65535),
    database: Object.freeze({
        host: process.env.DB_HOST || '127.0.0.1',
        port: readInteger('DB_PORT', 5432, 1, 65535),
        name: process.env.DB_NAME || 'faelo_ai',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD || '',
        ssl: readBoolean('DB_SSL', false)
    })
});

function assertDatabaseConfig() {
    if (!config.database.password || config.database.password.includes('GANTI_DENGAN')) {
        throw new Error('DB_PASSWORD has not been configured. Copy .env.example to .env and enter your PostgreSQL password.');
    }
}

module.exports = { config, assertDatabaseConfig };
