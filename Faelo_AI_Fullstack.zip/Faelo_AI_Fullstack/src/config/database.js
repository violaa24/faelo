const { Pool } = require('pg');
const { config, assertDatabaseConfig } = require('./env');

assertDatabaseConfig();

const pool = new Pool({
    host: config.database.host,
    port: config.database.port,
    database: config.database.name,
    user: config.database.user,
    password: config.database.password,
    ssl: config.database.ssl ? { rejectUnauthorized: false } : false,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    statement_timeout: 10_000,
    application_name: 'faelo_ai_website'
});

pool.on('error', (error) => {
    console.error('Unexpected PostgreSQL connection error:', error.message);
});

async function verifyDatabase() {
    const result = await pool.query("SELECT to_regclass('public.demo_requests') AS table_name");
    if (!result.rows[0].table_name) {
        throw new Error('The demo_requests table is missing. Run: npm run db:setup');
    }
}

module.exports = { pool, verifyDatabase };
