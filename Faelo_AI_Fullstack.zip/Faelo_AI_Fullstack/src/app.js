const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const { pool } = require('./config/database');
const demoRequestRoutes = require('./routes/demoRequestRoutes');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();
const publicDirectory = path.resolve(__dirname, '../public');

app.disable('x-powered-by');

app.use(helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com'],
            styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://cdnjs.cloudflare.com'],
            fontSrc: ["'self'", 'data:', 'https://fonts.gstatic.com', 'https://cdnjs.cloudflare.com'],
            imgSrc: ["'self'", 'data:'],
            connectSrc: ["'self'"],
            objectSrc: ["'none'"],
            baseUri: ["'self'"],
            formAction: ["'self'"],
            frameAncestors: ["'none'"],
            upgradeInsecureRequests: null
        }
    },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
}));

app.use(express.json({ limit: '32kb', strict: true }));

app.get('/api/health', async (req, res, next) => {
    try {
        const result = await pool.query('SELECT NOW() AS database_time');
        res.json({
            status: 'ok',
            database: 'connected',
            databaseTime: result.rows[0].database_time
        });
    } catch (error) {
        next(error);
    }
});

app.use('/api/demo-requests', demoRequestRoutes);
app.use(express.static(publicDirectory, {
    dotfiles: 'deny',
    etag: true,
    maxAge: '1h'
}));

app.use('/api', notFoundHandler);
app.use(errorHandler);

module.exports = app;
