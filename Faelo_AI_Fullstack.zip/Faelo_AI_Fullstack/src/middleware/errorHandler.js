function notFoundHandler(req, res) {
    res.status(404).json({ message: 'API endpoint not found.' });
}

function errorHandler(error, req, res, next) {
    if (res.headersSent) return next(error);

    console.error('Request failed:', error.message);

    if (error.type === 'entity.too.large') {
        return res.status(413).json({ message: 'The submitted form is too large.' });
    }

    if (error instanceof SyntaxError && error.status === 400 && 'body' in error) {
        return res.status(400).json({ message: 'The request contains invalid JSON.' });
    }

    return res.status(500).json({
        message: 'We could not save your request right now. Please try again shortly.'
    });
}

module.exports = { notFoundHandler, errorHandler };
