const app = require('./app');
const { config } = require('./config/env');
const { pool, verifyDatabase } = require('./config/database');

let server;

async function startServer() {
    try {
        await verifyDatabase();

        server = app.listen(config.port, config.host, () => {
            console.log('');
            console.log('Faelo AI is running successfully.');
            console.log(`Open this address in your browser: http://${config.host}:${config.port}`);
            console.log('Press Ctrl+C to stop the website.');
            console.log('');
        });
    } catch (error) {
        console.error('');
        console.error('Faelo AI could not start.');
        console.error(error.message);
        console.error('Check .env, make sure PostgreSQL is running, then run: npm run db:setup');
        console.error('');
        await pool.end().catch(() => {});
        process.exitCode = 1;
    }
}

async function shutdown(signal) {
    console.log(`\n${signal} received. Closing Faelo AI safely...`);

    if (server) {
        await new Promise((resolve) => server.close(resolve));
    }

    await pool.end();
    process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

startServer();
