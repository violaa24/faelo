const express = require('express');
const rateLimit = require('express-rate-limit');
const { submitDemoRequest } = require('../controllers/demoRequestController');

const router = express.Router();

const demoRequestLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 8,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
        message: 'Too many demo requests were sent from this connection. Please wait a few minutes and try again.'
    }
});

router.post('/', demoRequestLimiter, submitDemoRequest);

module.exports = router;
