const { randomUUID } = require('node:crypto');
const { createDemoRequest } = require('../repositories/demoRequestRepository');
const { validateDemoRequest } = require('../validation/demoRequest');

async function submitDemoRequest(req, res, next) {
    try {
        const validation = validateDemoRequest(req.body);

        // Silently accept automated submissions without storing them.
        if (validation.isBot) {
            return res.status(201).json({
                message: 'Your demo request has been received.',
                requestId: randomUUID()
            });
        }

        if (!validation.isValid) {
            return res.status(422).json({
                message: 'Please review the highlighted form information and try again.',
                errors: validation.errors
            });
        }

        const savedRequest = await createDemoRequest(validation.data);

        return res.status(201).json({
            message: 'Your demo request has been received.',
            requestId: savedRequest.request_id,
            createdAt: savedRequest.created_at
        });
    } catch (error) {
        return next(error);
    }
}

module.exports = { submitDemoRequest };
