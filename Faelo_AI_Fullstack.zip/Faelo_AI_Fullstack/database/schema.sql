CREATE TABLE IF NOT EXISTS demo_requests (
    id BIGSERIAL PRIMARY KEY,
    request_id UUID NOT NULL UNIQUE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(254) NOT NULL,
    phone VARCHAR(50),
    job_title VARCHAR(150) NOT NULL,
    company_name VARCHAR(200) NOT NULL,
    country_region VARCHAR(120) NOT NULL,
    manufacturing_industry VARCHAR(160) NOT NULL,
    current_data_sources VARCHAR(500) NOT NULL,
    primary_factory_challenge VARCHAR(1000) NOT NULL,
    factory_question VARCHAR(3000) NOT NULL,
    consent BOOLEAN NOT NULL CHECK (consent = TRUE),
    status VARCHAR(20) NOT NULL DEFAULT 'new'
        CHECK (status IN ('new', 'contacted', 'scheduled', 'closed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_demo_requests_created_at
    ON demo_requests (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_demo_requests_status
    ON demo_requests (status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_demo_requests_email
    ON demo_requests (LOWER(email));
