SELECT
    id,
    request_id,
    first_name,
    last_name,
    email,
    phone,
    job_title,
    company_name,
    country_region,
    manufacturing_industry,
    current_data_sources,
    primary_factory_challenge,
    factory_question,
    status,
    created_at
FROM demo_requests
ORDER BY created_at DESC;
